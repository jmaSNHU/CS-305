package com.snhu.sslserver;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

// implements a rest controller for the /hash endpoint
@RestController
class ServerController{ 
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Jacob Ard";
    	
    	byte[] hashBytes = Sha256ChecksumGenerator.computeHash(data);
    	String hexValue = Sha256ChecksumGenerator.getHexValue(hashBytes);
    	
        return "<p>data: " + data + "</p><p> SHA-256: " + hexValue + "</p>";
    }
}

// wrapper around a MessageDigest object
class Sha256ChecksumGenerator {
	// computes and returns a hashed byte array using the SHA-256 algorithm
	public static byte[] computeHash(String data) {
		try {
			// create a MessageDigest that implements the SHA-256 hashing algorithm
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			
			// compute hash and return byte array of hashed data
			return messageDigest.digest(data.getBytes());
		}
		catch (NoSuchAlgorithmException ex) {
			return null;
		}
	}
	
	// returns the hex value from hashed byte array
	public static String getHexValue(byte[] bytes) {
		// convert hash byte array into a positive big integer
		BigInteger tmpBigInt = new BigInteger(1, bytes);
		
		// convert big int into a hexadecimal string
		StringBuilder hexValue = new StringBuilder(tmpBigInt.toString(16));
		
		while (hexValue.length() < 64) {
			// add leading zeros if the string is less than 64 chars long
			hexValue.insert(0, '0');
		}
		return hexValue.toString();
	}
}
